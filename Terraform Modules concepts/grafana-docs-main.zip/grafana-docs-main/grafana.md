grafana download 
```
https://grafana.com/grafana/download
```

grafan starts
```
sudo /bin/systemctl daemon-reload
sudo /bin/systemctl enable grafana-server.service
sudo /bin/systemctl start grafana-server.service
```


grafana dashboards
```
https://grafana.com/grafana/dashboards/
```


